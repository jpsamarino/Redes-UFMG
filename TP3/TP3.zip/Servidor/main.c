//esse codio não esta bom


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <unistd.h>
#include <arpa/inet.h>
#include "tp_socket.h"
#define MaxTentativas_msg 30
//#define QtBytes 1000



int main(int argc, char** argv)
{

    if (argc != 3)
    {
        printf("Execulte da seguinte forma:\n %s <porta_servidor> <tam_buffer>", argv[0]);
        exit(0);
    }


    typedef struct frame
    {
        char frame_kind; //ACK:0, SEQ:1 FIN:2
        unsigned int sq_no;
        unsigned int ack;
        unsigned int QtBDados;
        char dados[atoi(argv[2])];

    } Frame;

    unsigned short port = atoi(argv[1]);
    int sockfd;
    struct sockaddr_in  newAddr; //struct sockaddr_in serverAddr, newAddr;
    struct timeval tv;
    int i,bytes;
    int w;
    int EndFrame=0;
    int flag;
    int tamanho_janela = 5;
    unsigned int frame_id=0;
    unsigned int QtBytes = atoi(argv[2]);
    unsigned int tamanho_arq;
    Frame frame_recv;
    Frame frame_send[tamanho_janela];
    FILE *origem;

    sockfd = tp_socket(port);


    /*************RECEBE NOME ARQ & LOCAL ****************************************************************************/
    // vou ter que mudar pq posso receber erro
    int f_recv_size = tp_recvfrom(sockfd,(char*)&frame_recv,sizeof(frame_recv),(struct sockaddr_in*)&newAddr);


    if(f_recv_size<sizeof(frame_recv))
    {
        printf("\n\n--O ARGUMENTO <tam_buffer> DEVE SER IGUAL PARA CLIENTE E SERVIDOR--\n\n");
        printf("\n\n--Modo de compatibilidade--\n\n");
        QtBytes = QtBytes - (sizeof(frame_recv)-f_recv_size);
    }

    else if (f_recv_size!=sizeof(frame_recv))
    {
        printf("\n\nO ARGUMENTO <tam_buffer> DEVE SER IGUAL PARA CLIENTE E SERVIDOR\n\n");
        return(-1);
    }

    if (f_recv_size > 0 && frame_recv.frame_kind == 1 && frame_recv.sq_no == frame_id)
    {
        printf("[+]Frame Recebido: %s\n", frame_recv.dados);

        frame_send[0].sq_no = 0;
        frame_send[0].frame_kind = 0;
        frame_send[0].ack = frame_recv.sq_no;
        tp_sendto(sockfd,(char*)&(frame_send[0]),sizeof(frame_send[0]),(struct sockaddr_in*)&newAddr);
        printf("[+]Ack enviado\n");
    }
    else //fechar o programa
    {

    }
    frame_id++;

    /************************************ABRE ARQUIVO****************************************************************/


    origem = fopen(frame_recv.dados, "rb");
    if(origem<=0)
    {
        printf("Arquivo não localizado\n Programas encerrados\n");
        frame_send[0].frame_kind = 3;
        tp_sendto(sockfd,(char*)&(frame_send[0]),sizeof(frame_send[0]),(struct sockaddr_in*)&newAddr);
        return -1;
    }
    else if((fseek(origem, 0, SEEK_END))<0)
    {
        printf("Arquivo Corrompido\n Programas encerrados\n");
        frame_send[0].frame_kind = 3;
        tp_sendto(sockfd,(char*)&(frame_send[0]),sizeof(frame_send[0]),(struct sockaddr_in*)&newAddr);
        return -1;
    }
    tamanho_arq =  ftell(origem);
    printf("qtb: %d\n",tamanho_arq );
    rewind (origem);//retorno o cursor para o inicio do arquivo

    /************CALCULA QT PACOTES NECESSARIOS****************************************************************/

    if (tamanho_arq%QtBytes != 0)
    {
        flag = 1;
    }

    unsigned int qtpacotes = tamanho_arq/QtBytes+flag;
    printf("QT pacotes que seram transmitidos %d\n",qtpacotes);

    /*************SETA TEMPO DO TIMER PARA CONTROLE******************************************************************/

    tv.tv_sec = 1; // DEFININDO UM TEMPO DE 1 SEGUNDO
    tv.tv_usec = 0;
    setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, (char*)&tv, sizeof(struct timeval));


    /*************COMECA A TRANSMISSAO DO ARQUIVO*****************************************/

    while(frame_recv.frame_kind!=2)  //TENTA ENVIAR/RECEBER DADOS ATE RECEBER A CONFIRMACAO DO ULTIMO FRAME
    {

        for ( w = 0 ; w< tamanho_janela; w++)
        {

            bytes = fread(frame_send[w].dados, sizeof(char), QtBytes, origem );

            frame_send[w].sq_no = frame_id+w; // ENVIA O FRAME
            frame_send[w].frame_kind = 1; // FALA Q É UM FRAME NORMAL
            frame_send[w].QtBDados = bytes;
            frame_send[w].ack = 0; //VALOR ARBITRARIO
            EndFrame = w;
             if(bytes!= QtBytes)
            {
                frame_send[w].frame_kind = 2;
            }

            tp_sendto(sockfd,(char*)&(frame_send[w]),sizeof(frame_send[w]),(struct sockaddr_in*)&newAddr); // já envia pela primeira vez

            printf("\nenvia - frame_id+w:%d",frame_id+w);

            if(bytes!= QtBytes)
            {   printf("\nEnviou o fim do arquivo");
                break;
            }


        }


        for(i=0; i<MaxTentativas_msg; i++) //tenta reenviar os frames N vezes
        {
            for (w = 0; w< tamanho_janela; w++)
            {

                f_recv_size = tp_recvfrom(sockfd,(char*)&frame_recv,sizeof(frame_recv),(struct sockaddr_in*)&newAddr);
                printf("\nRecebe W:%d",w);
                if(f_recv_size>0 && frame_recv.ack > frame_id && frame_recv.ack < frame_id+tamanho_janela)
                {

                    frame_id = frame_recv.ack;
                    printf("\n recebe-- frame_id:%d -- respostaframe %d",frame_id,frame_recv.frame_kind);

                    if (frame_recv.frame_kind == 2 || (frame_send[EndFrame].sq_no+1)==frame_id) // recebeu td que queria receber
                    {
                        printf("\ndeu break");
                        break;
                    }


                }

                else if(f_recv_size<=0)
                {
                    printf("\nestourou o tempo ou fora erro trans.");

                    break;
                }

                else if((frame_send[0].sq_no < frame_recv.ack && frame_send[0].sq_no < frame_recv.ack))
                {
                    printf("\nRECEBI Fora de ordem ACK = %d",frame_recv.ack);

                }
                else
                {
                    printf("\nRecebeu cabeçalho errado");
                }



            }

            if(frame_send[EndFrame].sq_no<frame_id) // se recebeu td sai do loop
            {
                printf("\nSAIU DO FOR");
                break;

            }

            else if(frame_recv.frame_kind ==2)
            {
                break;
            }

            else
            {   printf("\npassa aqui");
                for (w = (frame_id-frame_send[0].sq_no); w< tamanho_janela; w++) // conferir isso GO BACK N
                {

                    printf("\nReenviou - %d -",frame_send[w].sq_no);
                    tp_sendto(sockfd,(char*)&(frame_send[w]),sizeof(frame_send[w]),(struct sockaddr_in*)&newAddr); // já envia pela primeira vez

                }
            }

        }

        if(i>=MaxTentativas_msg && frame_send[EndFrame].frame_kind != 2 )
        {
            printf("\nERRO DE ENVIO DA MSG %d - SEM ACK - %d TENTATIVAS REALIZADAS\n",frame_id,i);
            return(-1); // finaliza o programa com erro
        }

    }


    fclose(origem);
    close(sockfd);
    return 0;
}
