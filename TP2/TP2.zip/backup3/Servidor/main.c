#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <unistd.h>
#include <arpa/inet.h>


typedef struct frame{
    char frame_kind; //ACK:0, SEQ:1 FIN:2
    int sq_no;
    int ack;
    char dados[1024];
}Frame;

int main(int argc, char** argv){

	if (argc != 2){
		printf("Usage: %s <port>", argv[0]);
		exit(0);
	}

	int port = atoi(argv[1]);
	int sockfd;
	struct sockaddr_in serverAddr, newAddr;
	char buffer[1024];
	socklen_t addr_size;
	struct timeval tv;

	int frame_id=0;
	Frame frame_recv;
	Frame frame_send;

	sockfd = socket(AF_INET, SOCK_DGRAM, 0);

	memset(&serverAddr, '\0', sizeof(serverAddr));
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(port);
	serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");

	bind(sockfd, (struct sockaddr*)&serverAddr, sizeof(serverAddr));

	addr_size = sizeof(newAddr);

/*************RECEBE NOME ARQ & LOCAL ****************************************************************************/

    int f_recv_size = recvfrom(sockfd, &frame_recv, sizeof(Frame), 0, (struct sockaddr*)&newAddr, &addr_size);

/*************SETA TEMPO DO TIMER PARA CONTROLE******************************************************************/

	tv.tv_sec = 10; // DEFININDO UM TEMPO DE 1 SEGUNDO
    tv.tv_usec = 0;
    setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, (char*)&tv, sizeof(struct timeval));


/*************COMECA A TRANSMISSAO DO ARQUIVO*****************************************/

	while(frame_recv.frame_kind!=2){ //TENTA ENVIAR/RECEBER DADOS ATE RECEBER A CONFIRMACAO DO ULTIMO FRAME

		if (f_recv_size > 0 && frame_recv.frame_kind == 1 && frame_recv.sq_no == frame_id){
			printf("[+]Frame Received: %s\n", frame_recv.dados);

			frame_send.sq_no = 0;
			frame_send.frame_kind = 0;
			frame_send.ack = frame_recv.sq_no + 1;

			sendto(sockfd, &frame_send, sizeof(frame_send), 0, (struct sockaddr*)&newAddr, addr_size);
			printf("[+]Ack Send\n");
		}else{
			printf("[+]Frame Not Received\n");
		}
		frame_id++;
		f_recv_size = recvfrom(sockfd, &frame_recv, sizeof(Frame), 0, (struct sockaddr*)&newAddr, &addr_size);
		printf("recebi mais n validei: %s sq_no:%d tipo:%d\n", frame_recv.dados,frame_recv.sq_no,frame_recv.frame_kind);
	}

	close(sockfd);
	return 0;
}
