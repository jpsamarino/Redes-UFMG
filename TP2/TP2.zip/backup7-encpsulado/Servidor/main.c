#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <unistd.h>
#include <arpa/inet.h>
#include "tp_socket.h"
#define MaxTentativas_msg 5
#define QtBytes 1024

typedef struct frame
{
    char frame_kind; //ACK:0, SEQ:1 FIN:2
    unsigned int sq_no;
    unsigned int ack;
    unsigned int QtBDados;
    char dados[QtBytes];
} Frame;

int main(int argc, char** argv)
{

    /*if (argc != 2)
    {
        printf("Use: %s <porta>", argv[0]);
        exit(0);
    }*/

    unsigned short port = 20000;
    int sockfd;
    struct sockaddr_in  newAddr; //struct sockaddr_in serverAddr, newAddr;
    //char buffer[1024];
    //socklen_t addr_size;
    struct timeval tv;
    int i,bytes;
    int flag;
    int frame_id=0;
    unsigned int tamanho_arq;
    Frame frame_recv;
    Frame frame_send;
    FILE *origem;

    sockfd = tp_socket(port);
    /*sockfd = socket(AF_INET, SOCK_DGRAM, 0);

    memset(&serverAddr, '\0', sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(port);
    serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    bind(sockfd, (struct sockaddr*)&serverAddr, sizeof(serverAddr));*/

    //addr_size = sizeof(newAddr);

/*************RECEBE NOME ARQ & LOCAL ****************************************************************************/
    int f_recv_size = tp_recvfrom(sockfd,(char*)&frame_recv,sizeof(frame_recv),(struct sockaddr_in*)&newAddr);
    //int f_recv_size = recvfrom(sockfd, &frame_recv, sizeof(Frame), 0, (struct sockaddr*)&newAddr, &addr_size);
    //fazer uma validacao e abrir arquivo
    //enviar um ack falando que recebbeu o nome do arquivo ou fechar td
    if (f_recv_size > 0 && frame_recv.frame_kind == 1 && frame_recv.sq_no == frame_id)
    {
        printf("[+]Frame Received: %s\n", frame_recv.dados);

        frame_send.sq_no = 0;
        frame_send.frame_kind = 0;
        frame_send.ack = frame_recv.sq_no;
        tp_sendto(sockfd,(char*)&(frame_send),sizeof(frame_send),(struct sockaddr_in*)&newAddr);
        //sendto(sockfd, &frame_send, sizeof(frame_send), 0, (struct sockaddr*)&newAddr, addr_size);
        printf("[+]Ack Send\n");
    }
    else //fechar o programa
    {

    }
    frame_id++;

/************************************ABRE ARQUIVO****************************************************************/


    origem = fopen(frame_recv.dados, "rb");
    if(origem<=0)
    {
        printf("Arquivo não localizado\n Programas encerrados\n");
        frame_send.frame_kind = 3;
        tp_sendto(sockfd,(char*)&(frame_send),sizeof(frame_send),(struct sockaddr_in*)&newAddr);
        //sendto(sockfd, &frame_send, sizeof(frame_send), 0, (struct sockaddr*)&newAddr, addr_size);
        return -1;
    }
    else if((fseek(origem, 0, SEEK_END))<0){
        printf("Arquivo Corrompido\n Programas encerrados\n");
        frame_send.frame_kind = 3;
        tp_sendto(sockfd,(char*)&(frame_send),sizeof(frame_send),(struct sockaddr_in*)&newAddr);
        //sendto(sockfd, &frame_send, sizeof(frame_send), 0, (struct sockaddr*)&newAddr, addr_size);
        return -1;
    }
    tamanho_arq =  ftell(origem);
    printf("qtb: %d\n",tamanho_arq );
    rewind (origem);//retorno o cursor para o inicio do arquivo

/************CALCULA QT PACOTES NECESSARIOS****************************************************************/

if (tamanho_arq%QtBytes != 0)
    {
         flag = 1;
    }

int qtpacotes = tamanho_arq/QtBytes+flag;
printf("QT pacotes que seram transmitidos %d\n",qtpacotes);

/*************SETA TEMPO DO TIMER PARA CONTROLE******************************************************************/

    tv.tv_sec = 1; // DEFININDO UM TEMPO DE 1 SEGUNDO
    tv.tv_usec = 0;
    setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, (char*)&tv, sizeof(struct timeval));


/*************COMECA A TRANSMISSAO DO ARQUIVO*****************************************/

    while(frame_recv.frame_kind!=2)  //TENTA ENVIAR/RECEBER DADOS ATE RECEBER A CONFIRMACAO DO ULTIMO FRAME
    {

        bytes = fread(frame_send.dados, sizeof(char), QtBytes, origem );
        printf("\n%d--bytes",bytes);
        frame_send.sq_no = frame_id; // ENVIA O FRAME 0
        frame_send.frame_kind = 1; // FALA Q É UM FRAME NORMAL
        frame_send.QtBDados = bytes;

        if(frame_id == qtpacotes)
        {
            frame_send.frame_kind = 2;
        }

        frame_send.ack = 0; //VALOR ARBITRARIO

        /*printf("D4: ");
        scanf("%s",buffer);
        strcpy(frame_send.dados, buffer);*/



        //addr_size = sizeof(serverAddr); ////////MUDAR ISSO DEPOIS


        for(i=0; i<MaxTentativas_msg; i++)
        {
            tp_sendto(sockfd,(char*)&(frame_send),sizeof(frame_send),(struct sockaddr_in*)&newAddr);
            //sendto(sockfd, &frame_send, sizeof(frame_send), 0, (struct sockaddr*)&newAddr, addr_size);
            f_recv_size = tp_recvfrom(sockfd,(char*)&frame_recv,sizeof(frame_recv),(struct sockaddr_in*)&newAddr);
            //f_recv_size = recvfrom(sockfd, &frame_recv, sizeof(Frame), 0, (struct sockaddr*)&newAddr, &addr_size);


            if(f_recv_size>0 && frame_recv.ack == frame_id+1 && frame_recv.frame_kind == 0)
            {
                break;
            }
            else if (f_recv_size>0 && frame_recv.frame_kind == 2)
            {
                break; //finaliza conexao
            }

            else
            {
                //outros erros, seram tratados?
            }

        }

        if(i>=MaxTentativas_msg)
        {
            printf("\nERRO DE ENVIO DA MSG %d - SEM ACK - %d TENTATIVAS REALIZADAS\n",frame_id,i);
            return(-1); // finaliza o programa com erro
        }

        printf("\nack %d - sqn %d \n ",frame_recv.ack,frame_recv.sq_no);
        frame_id++;





    }
    fclose(origem);
    close(sockfd);
    return 0;
}
