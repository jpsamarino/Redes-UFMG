/************* UDP CLIENT CODE *******************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/time.h>
#include "tp_socket.h"
#define Tentativas_s 3
#define SegundosEspera 5




int main(int argc, char *argv[])
{

    if (argc != 5)
    {
        printf("Execulte da seguinte forma:\n %s <host_do_servidor> <porta_servidor> <nome_arquivo> <tam_buffer>", argv[0]);
        exit(0);
    }


    typedef struct frame
    {
        char frame_kind; //ACK:0, SEQ:1 FIN:2
        unsigned int sq_no;
        unsigned int ack;
        unsigned int QtBDados;
        char dados[atoi(argv[4])];

    } Frame;


    int port = atoi(argv[2]);
    int sockfd;
    struct sockaddr_in serverAddr;
    struct timeval tv;
    int f_recv_size,tamanho_arquivo;
    unsigned int frame_id = 0 , QtBytes = atoi(argv[4]);
    Frame frame_send;
    Frame frame_recv;
    int ack_recv = 0;
    int i=0;
    FILE *destino;
    struct timeval now;
    double inicio, fim;



    sockfd = socket(AF_INET, SOCK_DGRAM, 0);

    memset(&serverAddr, '\0', sizeof(serverAddr));

    tp_build_addr(&serverAddr,argv[1], port);


    /**********************************DEFINIR ESTOURO DO TIMER**********************************************/
    tv.tv_sec = SegundosEspera;
    tv.tv_usec = 0;
    setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, (char*)&tv, sizeof(struct timeval));


    /**********************************ENVIAR NOME & LOCAL DO ARQUIVO****************************************/

    frame_send.sq_no = frame_id; // ENVIA O FRAME 0
    frame_send.frame_kind = 1; // FALA Q É UM FRAME NORMAL
    frame_send.ack = 0; //VALOR ARBITRARIO

    destino = fopen(argv[3], "wb");

    strcpy(frame_send.dados, argv[3]);


    while(ack_recv == 0 && i<Tentativas_s)
    {
        tp_sendto(sockfd,(char*)&(frame_send),sizeof(frame_send),(struct sockaddr_in*)&serverAddr);
        printf("[+]Arquivo solicitado\n");

        f_recv_size = tp_recvfrom(sockfd,(char*)&frame_recv,sizeof(frame_recv),(struct sockaddr_in*)&serverAddr);

        if( f_recv_size > 0 && frame_recv.sq_no == 0 && frame_recv.ack == frame_id)
        {
            printf("[+]Ack Recebido\n");
            ack_recv = 1;
            break;
        }

        else
        {
            i++;
        }

    }
    if(i>Tentativas_s-1)
    {
        printf("Servidor Não localizado,foram feitas %d tentativas, Programa Finalizado\n",Tentativas_s);
        return(0);
    }
    frame_id++; // espera receber opacote 1 a partidir daqui


    /*-----INICIANDO MEDIDA DE TEMPO--------------------------------------------------------------------------*/

    gettimeofday(&now,NULL);
    inicio = ( (double) now.tv_usec )/ 1000000.0;
    inicio += ( (double) now.tv_sec );

    /*******************************************************************************************************/

    while(frame_recv.frame_kind !=2)  // enquanto o servidor não enviar no ultimo pacote entra aqui
    {

        f_recv_size = tp_recvfrom(sockfd,(char*)&frame_recv,sizeof(frame_recv),(struct sockaddr_in*)&serverAddr);

        if (f_recv_size>0 && frame_id == frame_recv.sq_no)
        {
            frame_send.ack = frame_recv.sq_no+1;//falando q eu quero o proximo dado
            frame_send.sq_no = frame_recv.sq_no;
            frame_send.frame_kind = 0;
            if(frame_recv.frame_kind == 2)
            {
                frame_send.frame_kind = 2;
            }

            fwrite(frame_recv.dados, sizeof(char),frame_recv.QtBDados,destino); //grava no arquivo
            tp_sendto(sockfd,(char*)&(frame_send),sizeof(frame_send),(struct sockaddr_in*)&serverAddr);
            frame_id++; //se espera o proximo pacote

        }

        else if (f_recv_size<0) //não recebeu nada e estorou o timer
        {
            printf("\n\n(Estourou o tempo) %d Segundos sem resposta do servidor\nPrograma Finalizado\n",SegundosEspera);
            return -1;
        }
        else  // recebeu pacotes errados ou quebrados
        {
            if(frame_recv.frame_kind == 3)
            {
                printf("Erro no servidor (ARQ ñ Localizado,etc)\n");
                return -1;
            }

            tp_sendto(sockfd,(char*)&(frame_send),sizeof(frame_send),(struct sockaddr_in*)&serverAddr);

        }



    }

    //-----FINALIZANDO MEDIDA DO TEMPO-------------------------------

    tp_sendto(sockfd,(char*)&(frame_send),sizeof(frame_send),(struct sockaddr_in*)&serverAddr); // finalização dupla
    gettimeofday(&now,NULL);
    fim = ( (double) now.tv_usec ) / 1000000.0 ;
    fim += ( (double) now.tv_sec );

    tamanho_arquivo = (frame_recv.sq_no-1)*QtBytes + frame_recv.QtBDados;

    printf("\n\nBuffer = \%5d bytes,\%10.2lf kbps (\%d bytes em %lf s)\n\n",QtBytes,tamanho_arquivo/(1000.0*(fim - inicio)),tamanho_arquivo,fim - inicio);


    fclose(destino);
    close(sockfd);
    return 0;
}
