// Esse Codigo só foi postado com a finalidade de averiguação , sendo que sua postagem não era obrigatoria e o mesmo é adptação do primeiro para testes

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <math.h>

#define MINHAPORTA 20000    /* Porta que os usuarios irão se conectar*/
#define BACKLOG 10     /* Quantas conexões pendentes serão indexadas */
#define maxbuffer 1024

int main()
{
    int tamanho_buffer = 100000,tamanho_buffer2; // tamanho maximo para não fazer malloc
    char bf[tamanho_buffer];
    int tamanho_arquivo=-1;
    int Meusocket,qt_buffer;
    unsigned int slen;
    struct sockaddr_in remoto;
    int len = sizeof(remoto),flag=0,i,j,z,qt_loop;
    char buffer[maxbuffer],saida[maxbuffer];
    struct timeval now;
    double inicio, fim;
    float media,desvio;
    float amostra[1000];

    FILE *destino;


    if ((Meusocket = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        perror("socket");
        exit(1);
    }
    printf("Bem Vindo ao programa cliente \n");


    remoto.sin_family = AF_INET;
    remoto.sin_port = htons(MINHAPORTA);
    remoto.sin_addr.s_addr = inet_addr("127.0.0.1") ; /* coloca IP */
    memset(remoto.sin_zero,0x0,8);/* Zera o resto da estrutura */

    memset(buffer,0x0,1024);
    memset(saida,0x0,1024);
    //strcpy(buffer,"/home/jpsamarino/Dropbox/REDES/1.pdf");
    printf("Digite o arquivo com seu respectivo caminho no servidor \nex: /home/jpsamarino/Dropbox/REDES/1.pdf");
    printf("\ncaminho servidor:");
    scanf("%s",&buffer);
    printf("Agora digite o nome do caminho e arquivo da copia \nex: /home/jpsamarino/Dropbox/REDES/2.pdf");
    printf("\ncaminho copia:");
    scanf("%s",&saida);
    printf("\nEnvia a quantidade de teste (copias do arquivo):");
    scanf("%d",&qt_loop);
    printf("\nEnvia a quantidade de buffers :");
    scanf("%d",&qt_buffer);


    if ((connect(Meusocket, (struct sockaddr *)&remoto,len)) < 0)//esta diferente
    {
        perror("connect");

    }


    //---ENVIA PARA O SERVIDOR O ARQUIVO QUE SE DESEJA------------------------------

    send(Meusocket,&qt_loop,sizeof(qt_loop),0);  // envia a qt de testes
    send(Meusocket,&qt_buffer,sizeof(qt_buffer),0);

    send(Meusocket,buffer,strlen(buffer),0);// envia o arquivo e seu respectivo local


    //----RECEBE INF PARA RECEBER O ARQUIVO-------------------------------------------



    recv(Meusocket,&tamanho_arquivo,sizeof(tamanho_arquivo),0);

    slen = recv(Meusocket,&tamanho_buffer,sizeof(tamanho_buffer),0);


    if(slen>0)
    {

        printf("\nTamanho arq:%d Bytes\n Tamanho buffer:%d Bytes\n",tamanho_arquivo,tamanho_buffer);

    }

    tamanho_buffer2= floor(tamanho_buffer/qt_buffer);
    printf("tamanho_buffer media(Mb/s) desvio");

    for (z=1; z< qt_buffer; z++)
    {

        media = 0;
        // -------LOOP A PARTIR DESSE PONTO ---------------------------


        for (j=1; j<=qt_loop; j++)
        {

            destino = fopen(saida, "wb" ); // abre arquivo de saida

            //-----INICIANDO MEDIDA DE TEMPO-------------------------------

            gettimeofday(&now,NULL);
            inicio = ( (double) now.tv_usec ) / 1000000 ;
            inicio += ( (double) now.tv_sec );

            //-----RECEBENDO O ARQUIVO---------------------------------------

            if (tamanho_arquivo%tamanho_buffer != 0)
            {
                flag = 1;
            }
            //printf("\n%d",tamanho_arquivo/tamanho_buffer+flag);

            for (i=1; i<=tamanho_arquivo/tamanho_buffer+flag; i++)
            {

                recv(Meusocket,bf,tamanho_buffer,0);
                if(tamanho_buffer>tamanho_arquivo)
                {
                    slen=tamanho_arquivo;
                }
                else if (i*tamanho_buffer < tamanho_arquivo)
                {
                    slen = tamanho_buffer;
                }
                else
                {
                    slen =  tamanho_arquivo - (i-1)*tamanho_buffer;
                }
                //printf("\nbytes %d - %d - %d",slen,i,j);
                fwrite( bf, sizeof( char ), slen, destino );
                memset(bf,0x0,100000);
            }

            //-----FINALIZANDO MEDIDA DO TEMPO-------------------------------

            gettimeofday(&now,NULL);
            fim = ( (double) now.tv_usec ) / 1000000 ;
            fim += ( (double) now.tv_sec );


            amostra[j] = tamanho_arquivo/(1000000*(fim - inicio));
            media += amostra[j];
            //-----FINALIZANDO O PROGRAMA------------------------------------

            fclose(destino);
            remove(saida); // deleta a saida para não dar problema no sistema operacional
        }

        tamanho_buffer = tamanho_buffer - tamanho_buffer2;
        media = media/qt_loop;
        desvio = 0;
        for (i=1; i<=qt_loop; i++)
        {

            desvio += pow((amostra[i]-media),2);

        }
        desvio = desvio /(qt_loop-1);
        desvio = sqrt(desvio);

        printf("\n%d %f %f ",tamanho_buffer ,media,desvio);

    }


    printf("\n\nqts de Bytes realmente transferidos : %d\n",tamanho_arquivo*j*z);




    close(Meusocket);
    return 0;
}

