// Esse Codigo só foi postado com a finalidade de averiguação , sendo que sua postagem não era obrigatoria e o mesmo é adptação do primeiro para testes

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>


#define MINHAPORTA 20000     /* Porta que os usuarios irão se conectar*/
#define BACKLOG 10     /* Quantas conexões pendentes serão indexadas */

void seta_coneccao(int *Meusocket,struct sockaddr_in *local,int porta,int maxcon)
{
    if ((*Meusocket = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        perror("socket");
        exit(1);
    }


    (*local).sin_family = AF_INET;
    (*local).sin_port = htons(porta);
    (*local).sin_addr.s_addr = INADDR_ANY;   /* coloca IP automaticamente */
    memset((*local).sin_zero,0x0,8); /* Zera o resto da estrutura */

    if (bind(*Meusocket, (struct sockaddr*)(local), sizeof(*local))== -1) //função associa porta da maquina a seu socket
    {
        perror("bind");
        exit(1);
    }

    if (listen(*Meusocket, maxcon) < 0) //seta o numero maximo de concçoes
    {
        perror("listen");
        exit(1);
    }

}



int main()
{
    int tamanho_buffer = 1000,tamanho_buffer2;
    int Meusocket,client;
    struct sockaddr_in local;
    struct sockaddr_in remoto;
    int len = sizeof(remoto);
    int i,j,z;
    char bf[tamanho_buffer],arquivo[1024]; // char tem 8 bits ou sejá um byte
    int tamanho_arq,flag=0,qt_loop,qt_buffer;
    unsigned int bytes;

    printf("Bem Vindo ao programa servidor\n ----Aguardando cliente----\n");

    FILE *origem ;


    seta_coneccao(&Meusocket,&local,MINHAPORTA,1); // configura parametros

    if ((client = accept(Meusocket, (struct sockaddr *)&remoto,&len)) < 0) // para o processo até alguem se conectar
    {
        perror("accept");
    }

    recv(client,&qt_loop,sizeof(qt_loop),0); // recebe a quantidade de loops
    recv(client,&qt_buffer,sizeof(qt_buffer),0);

    i=recv(client,arquivo,sizeof(arquivo),0); // recebe o nome do arquivo
    arquivo[i]='\0';

    origem = fopen(arquivo, "rb");
    if((fseek(origem, 0, SEEK_END))<0)
    {
        printf("Arquivo não localizados");
    }
    tamanho_arq =  ftell(origem);

    send(client,&tamanho_arq,sizeof(tamanho_arq),0); // envia a quantidade de bytes que iram para o cliente
    send(client,&tamanho_buffer,sizeof(tamanho_buffer),0); // envia o tamanho do buffer


    tamanho_buffer2= floor(tamanho_buffer/qt_buffer);



    for (z=1; z< qt_buffer; z++)
    {

        rewind (origem);

        for (j=1; j<=qt_loop; j++)
        {

            rewind (origem);//retorno o cursor para o inicio do arquivo

            if (tamanho_arq%tamanho_buffer != 0)
            {
                flag = 1;
            }


            for (i=1; i<=tamanho_arq/tamanho_buffer+flag; i++)
            {

                bytes = fread( bf, sizeof( char ), tamanho_buffer, origem );

                if (bytes<1)
                {
                    printf("deu pau--%d, %d\n ",i,bytes);
                }

                send(client,bf,bytes,0);

            }

            printf("\n Qt de pacotes transferidos: %d d e %d Bytes\n",i,tamanho_arq/i);

        }

        tamanho_buffer = tamanho_buffer - tamanho_buffer2;
    }

    fclose(origem);


    close(client);
    close(Meusocket);
    return 0;
}


