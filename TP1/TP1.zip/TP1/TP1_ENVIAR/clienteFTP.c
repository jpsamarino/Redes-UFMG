#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h>


#define MINHAPORTA 20000  /* Porta que os usuarios irão se conectar*/
#define BACKLOG 10     /* Quantas conexões pendentes serão indexadas */
#define maxbuffer 1024

int main()
{
    int tamanho_buffer = 10000; // tamanho maximo para não fazer malloc
    char bf[tamanho_buffer];
    int tamanho_arquivo=-1;
    int Meusocket,slen;
    struct sockaddr_in remoto;
    int len = sizeof(remoto),flag=0,i;
    char buffer[maxbuffer],saida[maxbuffer];
    struct timeval now;
    double inicio, fim;

    FILE *destino;


    if ((Meusocket = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        perror("socket");
        exit(1);
    }
    printf("Bem Vindo ao programa cliente\n");


    //---------Define configuração de sockets----------------------------------------------------------------------

    remoto.sin_family = AF_INET;
    remoto.sin_port = htons(MINHAPORTA);
    remoto.sin_addr.s_addr = inet_addr("127.0.0.1"); /* coloca IP */
    memset(remoto.sin_zero,0x0,8);/* Zera o resto da estrutura */

    memset(buffer,0x0,1024);
    memset(saida,0x0,1024);

    printf("Digite o arquivo com seu respectivo caminho no servidor \nex: /home/jpsamarino/Dropbox/REDES/1.pdf");
    printf("\ncaminho servidor:");
    scanf("%s",&buffer);
    printf("Agora digite o nome do caminho e arquivo da copia \nex: /home/jpsamarino/Dropbox/REDES/2.pdf");
    printf("\ncaminho copia:");
    scanf("%s",&saida);

    if ((connect(Meusocket, (struct sockaddr *)&remoto,len)) < 0)//esta diferente
    {
        perror("connect");

    }


    //---ENVIA PARA O SERVIDOR O ARQUIVO QUE SE DESEJA--------------------------------------------------------


    send(Meusocket,buffer,strlen(buffer),0); // envia o arquivo e seu respectivo local

    //----RECEBE INF PARA RECEBER O ARQUIVO--------------------------------------------------------------------


    recv(Meusocket,&tamanho_arquivo,sizeof(tamanho_arquivo),0);
    slen = recv(Meusocket,&tamanho_buffer,sizeof(tamanho_buffer),0);

    if(slen>0)
    {
        printf("\nTamanho arq:%d Bytes\nTamanho buffer:%d Bytes\n",tamanho_arquivo,tamanho_buffer);

    }

    destino = fopen(saida, "wb" ); // abre arquivo de saida


    //-----INICIANDO MEDIDA DE TEMPO---------------------------------------------------------------------------

    gettimeofday(&now,NULL);
    inicio = ( (double) now.tv_usec )/ 1000000.0;
    inicio += ( (double) now.tv_sec );


    //-----RECEBENDO O ARQUIVO---------------------------------------

    if (tamanho_arquivo%tamanho_buffer != 0)
    {
        flag = 1;
    }

    for (i=1; i<=tamanho_arquivo/tamanho_buffer+flag; i++)
    {

        slen=recv(Meusocket,bf,tamanho_buffer,0);
        // printf("%d\n",slen);
        fwrite( bf, sizeof( char ), slen, destino );
    }


    //-----FINALIZANDO MEDIDA DO TEMPO-------------------------------

    gettimeofday(&now,NULL);
    fim = ( (double) now.tv_usec ) / 1000000.0 ;
    fim += ( (double) now.tv_sec );
    printf("qts de pacotes realmente transferidos: %d\n",i);

    printf("\nTEMPO LEVA PARA TRANSFERENCIA: %f segundos -- Taxa transf %f Mb/s\n",fim - inicio,tamanho_arquivo/(1000000.0*(fim - inicio)));
    printf("\n\nBuffer = \%5d bytes, \%10.2lf kbps (\%d bytes em %lf s)\n\n",tamanho_buffer,tamanho_arquivo/(1000.0*(fim - inicio)),tamanho_arquivo,fim - inicio);

    //-----FINALIZANDO O PROGRAMA------------------------------------

    fclose(destino);
    



    close(Meusocket);
    return 0;
}

