#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>


#define MINHAPORTA 20000    /* Porta que os usuarios irão se conectar*/
#define BACKLOG 10     /* Quantas conexões pendentes serão indexadas */


//-------------Função que seta Configuração de socket---------------------------------------------------------------------------------

void seta_coneccao(int *Meusocket,struct sockaddr_in *local,int porta,int maxcon)
{
    if ((*Meusocket = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        perror("socket");
        exit(1);
    }


    (*local).sin_family = AF_INET;
    (*local).sin_port = htons(porta);
    (*local).sin_addr.s_addr = INADDR_ANY;   /* coloca IP automaticamente */
    memset((*local).sin_zero,0x0,8); /* Zera o resto da estrutura */

    if (bind(*Meusocket, (struct sockaddr*)(local), sizeof(*local))== -1) //função associa porta da maquina a seu socket
    {
        perror("bind");
        exit(1);
    }

    if (listen(*Meusocket, maxcon) < 0) //seta o numero maximo de concçoes
    {
        perror("listen");
        exit(1);
    }

}
//--------------------------------------------------------------------------------------------------------------------


int main()
{
    int tamanho_buffer = 10000;  // Define o tamanho do buffer , deve ser mudado no programa cliente tambem
    int Meusocket,client;
    struct sockaddr_in local;
    struct sockaddr_in remoto;
    int len = sizeof(remoto);
    int i;
    char bf[tamanho_buffer],arquivo[1024]; // char tem 8 bits ou sejá um byte
    int tamanho_arq,flag=0;
    unsigned int bytes;
    FILE *origem;

    printf("Bem Vindo ao programa servidor\n ----Aguardando clientes----\n");

//-----SETA CONFIGURAÇÂO-------------------------------------------------------------------------------------------

    seta_coneccao(&Meusocket,&local,MINHAPORTA,1); // configura parametros

    if ((client = accept(Meusocket, (struct sockaddr *)&remoto,&len)) < 0) // para o processo até alguem se conectar
    {
        perror("accept");
    }


    i=recv(client,arquivo,sizeof(arquivo),0); // recebe o nome do arquivo
    arquivo[i]='\0';

//------------------------------------------------------------------------------------------------------------------

//-----ABRE ARQUIVO e VERIFICA O TAMANHO DO MESMO-------------------------------------------------------------------

    origem = fopen(arquivo, "rb");
    if((fseek(origem, 0, SEEK_END))<0)
    {
        printf("Arquivo não localizado");
    }
    tamanho_arq =  ftell(origem);
    rewind (origem);//retorno o cursor para o inicio do arquivo

//------------------------------------------------------------------------------------------------------------------

//-----INICIA A TRANSFERENCIA DO ARQUIVO----------------------------------------------------------------------------


    send(client,&tamanho_arq,sizeof(tamanho_arq),0); // envia a quantidade de bytes que iram para o cliente
    send(client,&tamanho_buffer,sizeof(tamanho_buffer),0); // envia o tamanho do buffer


    if (tamanho_arq%tamanho_buffer != 0)
    {
        flag = 1;
    }

    for (i=1; i<=tamanho_arq/tamanho_buffer+flag; i++) // Calcula quantidade de pacotes que seram enviados
    {

        bytes = fread( bf, sizeof( char ), tamanho_buffer, origem );
        if (bytes<1)
        {
            printf("Houve problemas na transmição--%d, %d\n ",i,bytes);
        }
        //fwrite( bf, sizeof( char ), bytes, destino );
        send(client,bf,bytes,0);

    }

//---------------------FINALIZA PROGRAMA e FECHA CONEXÂO -------------------------------------------------


    printf("\n Qt de pacotes transferidos: %d de %d Bytes\n",i,tamanho_arq/i);

    fclose(origem);


    close(client);
    close(Meusocket);

    return 0;
}


